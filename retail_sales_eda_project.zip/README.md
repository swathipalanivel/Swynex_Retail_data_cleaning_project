# Retail Sales Exploratory Data Analysis (EDA)

## Project objective
Explore a cleaned public Online Retail transaction dataset to calculate summary statistics, identify trends and anomalies, and communicate useful business insights.

## Dataset
- Source: UCI Machine Learning Repository — Online Retail
- URL: https://archive.ics.uci.edu/dataset/352/online+retail
- Period in supplied file: 2010-12-01 to 2011-12-09
- Rows: 536,641
- Columns: 10

## Tools
Python, Pandas, Matplotlib, GitHub.

## Analysis approach
For sales trend analysis, the analysis uses transaction lines with Quantity > 0, UnitPrice > 0, and invoice numbers not beginning with `C`. Revenue is recalculated as Quantity × UnitPrice. Negative quantities and cancellation records are treated as return/cancellation indicators and discussed separately rather than mixed into gross sales.

## Key metrics
- Gross sales revenue: £10,642,110.80
- Sales invoices: 19,960
- Unique identified customers: 4,372
- Countries: 38
- Units sold: 5,572,420
- Average sales value per invoice: £533.17

## Key insights
1. The United Kingdom contributes 84.6% of gross sales revenue, indicating strong geographic concentration.
2. 2011-11 is the highest-revenue month in the supplied data (£1,503,866.78). December 2011 is incomplete because the dataset ends on 9 December, so it should not be compared with full months.
3. Thursday has the highest gross revenue among weekdays with recorded sales. Saturday has no recorded sales in this dataset.
4. United Kingdom is the leading country by revenue (£9,001,744.09).
5. The top revenue product description is `DOTCOM POSTAGE` (£206,248.77); interpret cautiously because service/adjustment descriptions can appear alongside physical products.
6. The top 10 customers account for 17.3% of identified-customer gross revenue, suggesting some customer concentration.

## Anomaly and data-quality observations
- Rows with negative quantity: 10,587; these may represent returns or credit transactions.
- Cancellation invoice rows (invoice number begins with C): 9,251.
- Rows with zero unit price: 2,510; investigate before treating them as ordinary sales.
- Rows with negative unit price: 2; investigate separately.
- CustomerID has missing values in the supplied cleaned file; customer-level calculations exclude unidentified customers.

## Files
- `exploratory_analysis.py`: reproducible analysis script.
- `charts/`: generated charts.
- `README.md`: project documentation.

## Limitations
The dataset is historical and ends on 9 December 2011. Revenue is treated as the dataset's currency (GBP, based on the UCI dataset description). These are descriptive findings, not causal explanations or forecasts.
