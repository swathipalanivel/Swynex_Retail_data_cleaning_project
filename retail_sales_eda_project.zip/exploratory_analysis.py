import pandas as pd

# Load the cleaned retail dataset
df = pd.read_csv("cleaned_retail_data.csv", parse_dates=["InvoiceDate"])
df["InvoiceNo"] = df["InvoiceNo"].astype(str)

# Flag cancellations and define completed positive-quantity sales.
df["is_cancel"] = df["InvoiceNo"].str.startswith("C")
sales = df[(df["Quantity"] > 0) &
           (df["UnitPrice"] > 0) &
           (~df["is_cancel"])].copy()

sales["Revenue"] = sales["Quantity"] * sales["UnitPrice"]
sales["Month"] = sales["InvoiceDate"].dt.to_period("M").astype(str)

print("Dataset shape:", df.shape)
print("Missing values:\\n", df.isna().sum())
print("Exact duplicate rows:", df.duplicated().sum())
print("\\nSales summary:")
print(sales[["Quantity", "UnitPrice", "Revenue"]].describe())

print("\\nMonthly revenue:")
print(sales.groupby("Month")["Revenue"].sum().sort_index())

print("\\nTop 10 countries:")
print(sales.groupby("Country")["Revenue"].sum().nlargest(10))

print("\\nTop 10 products:")
print(sales.groupby("Description")["Revenue"].sum().nlargest(10))

print("\\nSales by weekday:")
print(sales.groupby(sales["InvoiceDate"].dt.day_name())["Revenue"].sum())

print("\\nPotential anomalies:")
print("Negative quantity rows:", (df["Quantity"] < 0).sum())
print("Zero unit-price rows:", (df["UnitPrice"] == 0).sum())
print("Negative unit-price rows:", (df["UnitPrice"] < 0).sum())
